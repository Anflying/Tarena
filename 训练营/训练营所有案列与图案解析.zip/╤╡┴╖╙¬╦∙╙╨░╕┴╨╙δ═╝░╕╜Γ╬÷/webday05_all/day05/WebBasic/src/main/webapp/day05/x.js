function f3() {
	alert("王克晶");
}